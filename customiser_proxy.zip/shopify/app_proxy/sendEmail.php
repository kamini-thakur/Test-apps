<?php 

$name = $_POST['fname'];
$email = $_POST['email'];
$message = $_POST['message'];
$company_email = "test@gmail.com";

// First image
if (file_exists("upload/" . $_FILES["image1"]["name"])) {
echo $_FILES["image1"]["name"] . " <b>already exists.</b> ";
}
else {
move_uploaded_file($_FILES["image1"]["tmp_name"],
"upload/" . $_FILES["image1"]["name"]);
echo "<b>Stored in:</b> " . "upload/" . $_FILES["image1"]["name"]."<br>";
$image1 = "http://esferaitconsultants.com/shopify/app_proxy/upload/".$_FILES["image1"]["name"];
}

// Second image
if (file_exists("upload/" . $_FILES["image2"]["name"])) {
echo $_FILES["image2"]["name"] . " <b>already exists.</b> ";
}
else {
move_uploaded_file($_FILES["image2"]["tmp_name"],
"upload/" . $_FILES["image2"]["name"]);
echo "<b>Stored in:</b> " . "upload/" . $_FILES["image2"]["name"]."<br>";
$image2 = "http://esferaitconsultants.com/shopify/app_proxy/upload/".$_FILES["image2"]["name"];
}

// Third image
if (file_exists("upload/" . $_FILES["image3"]["name"])) {
echo $_FILES["image3"]["name"] . " <b>already exists.</b> ";
}
else {
move_uploaded_file($_FILES["image3"]["tmp_name"],
"upload/" . $_FILES["image3"]["name"]);
echo "<b>Stored in:</b> " . "upload/" . $_FILES["image3"]["name"]."<br>";
$image3 = "http://esferaitconsultants.com/shopify/app_proxy/upload/".$_FILES["image3"]["name"];
}

echo 'fname='.$name.' email='.$email.' image1='.$image1.' image2='.$image2.' image3='.$image3.' message='.$message;

	$to = "kamini_thakur@esferasoft.com";
	$subject = "Test on product customiser app to send image form";
	$headers = "From: $company_email\n";
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers = "Content-type:text/html;charset=UTF-8" . "\r\n";

	$message = "<p>A visitor to your site has sent the following email address to be added to your mailing list.</p>
	<p><b>Name:</b> $name </p>
	<p><b>Email:</b> $email </p>
	<p><b>Message:</b> $message </p>";

	mail($to,$subject,$message,$headers);

?>