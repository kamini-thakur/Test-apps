<?php 

header('Content-Type: application/liquid');

?>

<div class="grid">
        <div class="grid__item">
          <div class="section-header">
  <h1 class="section-header--title">Contact us</h1>
</div>

<div class="rte">
  
</div>

<div>
  <div class="successDisplay" style="display: none;">Data sent successfully</div>
  <form method="post" id="send_data" class="contact-form" enctype=”multipart/form-data”>

    <label for="ContactFormName" class="label--hidden">Name</label>
    <input id="ContactFormName" name="fname" placeholder="Name" autocapitalize="words" value="" type="text">

    <label for="ContactFormEmail" class="label--hidden">Email</label>
    <input id="ContactFormEmail" name="email" placeholder="Email" autocorrect="off" autocapitalize="off" value="" type="email">

    <label for="ContactFormFile" class="label--hidden">Images</label>
    <input id="ContactFormFile1" name="image1" type="file">
    <input id="ContactFormFile2" name="image2" type="file">
    <input id="ContactFormFile3" name="image3" type="file">

    <label for="ContactFormMessage" class="label--hidden">Message</label>
    <textarea rows="10" id="ContactFormMessage" name="message" placeholder="Message"></textarea>

    <button>Submit</button>

  </form>

</div>

        </div>
    </div>


<script type="text/javascript">
// $("#send_data").on('submit', function(e){
//     e.preventDefault();
//     alert('sending');
// 	// var data = $('#send_data').serialize();
// 	var image = $('input[type=file]')[0].files[0];
// 	alert(image);
// 	// data = data+"&image1="+file;

// 	var form_data = new FormData();                
// 	form_data.append("image1", image);

// 	alert(form_data);
// 		$.ajax({ 
// 			url: "http://esferaitconsultants.com/shopify/app_proxy/sendEmail.php", 
// 			type: "POST", 
// 			data: form_data, 
// 			success: function(result) { 
// 				// $(body).html(result);
// 				alert(result);
// 				$('.successDisplay').css('display','block');
// 				$("form.contact_form")[0].reset(); 
// 				setTimeout(function(){ $('.successDisplay').hide(); }, 3000);
// 			}

// 	}); 
// });

$("form#send_data").submit(function(e) {
    e.preventDefault();    
    var formData = new FormData(this);

    $.ajax({
        url: "http://esferaitconsultants.com/shopify/app_proxy/sendEmail.php",
        type: 'POST',
        data: formData,
        success: function (data) {
            // alert(data);
            $('.successDisplay').css('display','block');
			$("form.contact_form")[0].reset(); 
			setTimeout(function(){ $('.successDisplay').hide(); }, 3000);
        },
        cache: false,
        contentType: false,
        processData: false
    });
});
</script>