<?php

$api_key= "061260ac9e3a2eab5eb8e98fceb974e1";
$secret= "b8a4db75d56a4d002e5250b76739e785";

?>