<?php
/*
Template Name: auth1
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

$image = esc_url(plugins_url('../assets/images/loader-v1.gif',__FILE__));
$url = get_site_url();
$shop_val = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
$_DOMAIN = $shop_val;

$ms = new MalcaAmitShippingService();
$var = $ms->malca_get_access_token($_DOMAIN);
$token =  $var['token'];

if(current_user_can('administrator')){
  if(isset($_POST['singup'],$_POST['companyname'],$_POST['companywebsite'],$_POST['contactperson'],$_POST['phone'],$_POST['emailsignup']))
  {
    if(!isset( $_POST['malca_amit_my_nonce'] ) && !wp_verify_nonce($_POST['malca_amit_my_nonce'], 'malca_amit_nonce_action'))
    {

      echo "<div class='alert alert-danger'><h3 style='text-align:center;'>'Failed security check'<h3></div>";
    }
    else

    {

      $company_name = sanitize_text_field($_POST['companyname']);
      $companywebsite= sanitize_text_field($_POST['companywebsite']);
      $contactperson =sanitize_text_field($_POST['contactperson']);
      $phone = sanitize_text_field($_POST['phone']);
      $emailsignup = sanitize_email($_POST['emailsignup']) ;
      if(is_email($emailsignup)){
        $msg = $ms->malca_sinup_mail($_DOMAIN,$token,$company_name,$companywebsite,$contactperson,$phone,$emailsignup);
        if($msg == 'success')
        {
          $redirect_url=admin_url("post.php?page=malca-amit-shipping-service/template/singup_dashboard.php");
          wp_redirect($redirect_url);
        }

        else
        {
          echo "<div class='alert alert-danger'><h3 style='text-align:center;'>Somthing went wrong. SignUp mail does not send ,contact to plugin Auther<h3></div>";
        }   

      }

      else
      {
        echo "<div class='alert alert-danger'><h3 style='text-align:center;'>Email does not exists<h3></div>";
      }      
    }

  }
}
else{
  echo "not administrator";
}

?>

<!DOCTYPE html>
<html>
<head>
</head>
<body class="home_new">
  <div class="content container">

    <div class="col-sm-12 app_header">
      <div class="row">
        <div class="logo">
          <div id="divPortalHeaderImage"></div>
        </div>
      </div>
    </div>

    <div class="page_content">

      <h3>Malca-Amit is a global secure logistics provider, specializing in door-to-door shipping within the Diamond & Jewelry, Watch and many others valuable goods.</h3>
    </div>
    <div class="loging-signup">
      <div class="row">
        <div class="left-first-sec col-md-4 col-sm-12 col-xs-12">
          <ul>
            <li>Easily Create Shipping Labels For <strong>FedEx</strong>, <strong>UPS</strong> and <strong>USPS</strong>.</li>
            <li>Get Up To <strong>50% Less</strong> Than Market Price on Each Transactions.</li>
            <li>Insured Every Transaction <strong>Up To $100,000.</strong></li>
            <li>Track Your Shipment And be Notified upon Delivery.</li>
            <li><strong>All Calls Are Personally Answered.</strong></li>

          </ul>
        </div>
        <div class="col-md-8 col-sm-12 col-xs-12 middle_form">
          <div class="left-section col-sm-6">
           <?php

           if(isset($_POST['login'],$_POST['username'],$_POST['password'],$_POST['stationcode']))
           { 

            if(!isset( $_POST['malca_amit_mylogin_nonce'] ) && !wp_verify_nonce($_POST['malca_amit_mylogin_nonce'], 'malca_amit_login_nonce'))
            {
             echo "<div class='alert alert-danger'><h3 style='text-align:center;'>'Failed security check'<h3></div>";
           }
           else{
            $username = sanitize_text_field($_POST['username']);
            $password=sanitize_text_field($_POST['password']);
            $satationcode=sanitize_text_field( $_POST['stationcode']);


            $result = $ms->malca_auth_malcauser($_DOMAIN, $username,  $password,  $satationcode,$token);

            if($result == 200)
            {

              $ms->malca_setUserInfo($_DOMAIN,$username,  $password, $satationcode);
              $ms->malca_login_status($_DOMAIN);
              $ms->malca_submit_logindetails($_DOMAIN,$token,$username,  $password,  $satationcode);

              $redirect_url=admin_url("post.php?page=malca-amit-shipping-service/template/order.php");
              wp_redirect($redirect_url);

            }
            else
            {

            	echo "<div class='alert alert-danger'>
              username and password wrong
              </div>";

            }
          }

        } 
        ?>  
        <section class="loginform cf">
          <h1>Login</h1>
          <div class="col-sm-12">
            <div class="row">
              <form name="login" action="" method="post" id="lioff" accept-charset="utf-8">
                <?php wp_nonce_field( 'malca_amit_login_nonce', 'malca_amit_mylogin_nonce' ); ?>

                <ul>
                  <div class="col-sm-12">
                    <li>
                      <!-- <label for="usermail">Username</label> -->
                      <input type="text" name="username" placeholder="user name" required>
                    </li>
                  </div>
                  <div class="col-sm-12">
                    <li>
                      <!-- <label for="password">Password</label> -->
                      <input type="password" name="password" placeholder="password" required>
                    </li>
                  </div>
                  <div class="col-sm-12">
                    <li>
                      <!-- <label for="stationcode">Stationcode</label> -->
                      <input type="stationcode" name="stationcode" placeholder="station code" required>
                    </li>
                  </div>
                  <div class="col-sm-12">
                    <li>
                      <input type="submit" name="login" value="Login" class="logindata">
                    </li>
                  </div>

                </ul>
              </form>
            </div>
          </div>
        </section>
      </div>

      <div class="right_content col-sm-6">
        <div  class="animate form">
          <section class="loginform cf ">
            <h1 id="signup">Sign Up</h1>
            <div class="col-sm-12" >

              <div class="row">
                <form  action=""  name="register" method="post" id="register" autocomplete="on"> 
                  <?php wp_nonce_field( 'malca_amit_nonce_action', 'malca_amit_my_nonce' ); ?>
                  <ul>
                    <div class="col-sm-12">
                      <li>
                        <!--        <label for="companyname" class="cname" data-icon="u">Company Name</label> -->
                        <input id="companyname" name="companyname" required="required" type="text" placeholder="Company Name" />
                      </li>
                    </div>

                    <div class="col-sm-12">
                      <li> 
                        <!-- <label for="contactperson" class="cprerson" data-icon="e" >Contact person</label> -->
                        <input id="companywebsite" name="companywebsite" type="text" placeholder="Company Website">
                      </li>
                    </div>

                    <div class="col-sm-12">
                      <li> 
                        <!-- <label for="contactperson" class="cprerson" data-icon="e" >Contact person</label> -->
                        <input id="contactperson" name="contactperson" required="required" type="text" placeholder="Contact Person"/> 
                      </li>
                    </div>

                    <div class="col-sm-12">
                      <li> 
                        <!-- <label for="phone" class="phone" data-icon="p">Phone</label> -->
                        <input id="phone" name="phone" required="required" type="text" placeholder="Phone"/>
                      </li>
                    </div>
                    <div class="col-sm-12">

                      <li> 
                        <!--  <label for="emailsignup" class="youmail" data-icon="e" >Your email</label> -->
                        <input id="emailsignup" name="emailsignup" required="required" type="email" placeholder="Email"/> 
                      </li>
                    </div>
                    <div class="col-sm-12">
                      <li class="signin button"> 
                        <input type="submit" value="Sign up" name="singup"  class="logindata" /> 
                        <a href="">
                        </li>
                      </div>
                    </ul>
                  </form>
                </div>
              </div>
            </section>
          </div>
        </div>

      </div>

      <div class="col-sm-12 shopping-outer">
        <p class="shopping"><strong>Start Save on Your Shipping Today!</strong><span>1-844-MY-MALCA</span>
        (1-844-696-2522)</p>
      </div>
      <div class="modal fade" id="mModal" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-body">
              <p><img src="<?php echo $image; ?>"></p>
            </div>
          </div> 
        </div>
      </div> 
    </div>
  </div>
</div>
</div>

</body>

</html>


