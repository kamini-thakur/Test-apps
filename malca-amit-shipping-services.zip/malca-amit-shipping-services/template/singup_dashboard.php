<?php
   /*
   Template Name: Pending Signup
   */

   
   // Exit if accessed directly.
   if ( ! defined( 'ABSPATH' ) ) {
      exit;
   }

   $image = plugins_url('../assets/images/loader-v1.gif',__FILE__);
   
   
   ?>
<!DOCTYPE html>
<html>
   <head></head>
   <body class="home_new">
      <div class="content container">
         <div class="col-sm-12 app_header">
            <div class="row">
               <div class="logo">
                  <div id="divPortalHeaderImage"></div>
               </div>
            </div>
         </div>
         <div class="page_content table-responsive">
            <ul class="tabs">
               <li class="tab-link " data-tab="tab-1">Open</li>
               <li class="tab-link " data-tab="tab-2">Filter</li>
            </ul>
            
            <table id= "mytable" class="table malcaordertable table-hover mytable1 expanded display" style="background:#fff;font-size:14px;font-weight: normal;" cellspacing="0" width="100%">
               <thead>
                  <th class="is-sortable order">Order</th>
                  <th class="is-sortable date">Date</th>
                  <th class="is-sortable tcn">Tracking Number</th>
                  <th class="is-sortable customer">Est.Cost</th>
                  <th class="is-sortable customer">Customer</th>
                  <th class="is-sortable totalth">Total</th>
                  <th class="is-sortable text-center payment_status">Order Status</th>
                  <th class="is-sortable ">Fulfilment Status</th>
                  <th class="is-sortable fulfillment_status">Download Label</th>
               </thead>
               <tbody>
                  <tr>
                     <td colspan="12">
                        <div class="text-center thankyou_page welcome_page">
                           <h1>Thank You for signing up to Malca-Amit Express</h1>
                           <p class="center">
                              Your Malca-Amit Account is pending for approval, One of our Shipping expert will contact you shortly<br>
                              If you already got your credential, Please click <a href="<?php echo admin_url("admin.php?page=malca-amit-shipping-service/template/auth1.php");?>">here </a>  to login.<br>
                              <br>For resubmit your registration request, Please click <a href="<?php echo admin_url("admin.php?page=malca-amit-shipping-service/template/auth1.php");?>">here</a>.<br>
                           </p>
                        </div>
                     </td>
                  </tr>
               </tbody>
            </table>
         </div>
         <!-- Modal -->
         <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
               <div class="modal-content">
                  <div class="modal-body">
                     <p><img src="<?php echo $image ; ?>"/></p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php require_once('footer.php'); ?>