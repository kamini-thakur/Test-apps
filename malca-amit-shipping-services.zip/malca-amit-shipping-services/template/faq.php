<?php
   /*
   Template Name: FAQ
   */

   // Exit if accessed directly.
   if ( ! defined( 'ABSPATH' ) ) {
      exit;
   }

   $image = plugins_url('../assets/images/loader-v1.gif',__FILE__);
   
   
   ?>
   
<!DOCTYPE html>
<html>
   <head></head>
   <body class="home_new">
      <div class="content container">
         <div class="col-sm-12 app_header">
            <div class="row">
               <div class="logo">
                  <div id="divPortalHeaderImage"></div>
               </div>
            </div>
         </div>
         <div class="page_content">
            <div class="faq-outer">
               <div class="faq-header faq-head">Frequently Asked Questions</div>
               <div class="faq-c">
                  <div class="faq-q"><span class="faq-t">+</span><b>Why Malca-Amit Express Shipping?</b></div>
                  <div class="faq-a" style="display: none;">
                     <p>MA Express is an insured shipping service provided by Malca-Amit, which since 1963 has been the worldwide leader in diamonds, jewelry and precious metals logistics. By combining the services of leading international couriers with Malca-Amit's liability coverage, we provide a cost-effective shipping solution enabling the rapid delivery of lower and mid-value luxury goods. <br>
                        Malca-Amit's hard-earned reputation comes from decades of transporting precious metals, gems, jewellery, rare artifacts and other collectibles between countries and continents with flawless security and efficiency. Our clients benefit from technological.
                     </p>
                  </div>
               </div>
               <div class="faq-c">
                  <div class="faq-q"><span class="faq-t">+</span><b>Why Malca-Amit coverage is superior?</b></div>
                  <div class="faq-a" style="display: none;">
                     <p>The vast majority of Malca-Amit’s policy is placed at Lloyds of London, with the remainder placed with London Insurance companies with an A rating.<br>
                        Do you know who your secure logistics company’s insurance policy is placed with and are you familiar with the insurance companies’ financial ratings? MAEX coverage will not only save you money on every shipment, but we’ll also cover many items that other shipping carriers will not. If you do have any claims to file, we process them quickly and fairly. There are no long term commitments.
                     </p>
                     <p></p>
                  </div>
               </div>
               <div class="faq-c">
                  <div class="faq-q"><span class="faq-t">+</span><b>What type of commodities can be covered with Malca-Amit?</b></div>
                  <div class="faq-a" style="display: none;">
                     <p><b>Fine Jewelry</b> Gold/Platinum/Silver, with or without set stones.</p>
                     <p><b>Fashion jewelry </b>of various alloys</p>
                     <p><b>Diamonds</b> said to be polished and cut diamonds, other precious and semi-precious stones.</p>
                     <p><b>High-end Watches</b></p>
                     <p><b>Luxury Goods,</b> meaning branded high end goods.</p>
                     <p>Non-Activated Cellular Phones</p>
                     <p>Non-Activated Credit Cards</p>
                     <p><b> Coins,</b> meaning bullion coins of gold, silver or other precious metals.</p>
                     <p><b>Precious Metals</b> meaning bullion said to be gold, platinum, silver or other precious metals, in the form of a bar or other form..</p>
                     <p><b>Scrap Metals,</b> meaning gold, platinum, silver or other precious metals the purity of which is below 99.997%.</p>
                     <p>For coverage for other commodities please contact Malca-Amit at 1-800- MyMalca</p>
                  </div>
               </div>
               <div class="faq-c">
                  <div class="faq-q"><span class="faq-t">+</span><b>How to become a customer?</b></div>
                  <div class="faq-a" style="display: none;">
                     <p>Simply register on Malca-Amit main login page and a Malca-Amit costumer care expert will contact you within 24 hours to finalize your shipping account. <br>
                        Already a customer? Just login using your user name and password and enjoy worry free shipping!
                     </p>
                  </div>
               </div>
               <div class="faq-c">
                  <div class="faq-q"><span class="faq-t">+</span><b>How to submit a claim?</b></div>
                  <div class="faq-a" style="display: none;">
                     <p>Customer under no circumstances is to submit any claim in writing to the Courier. All notice of claim is to be in writing and must be received by Malca-Amit within twenty-four (24) hours after discovery of any loss or damage but in no event more than fourteen (14) days from the date the MAEX-Shipment was delivered or should have been delivered. </p>
                  </div>
               </div>
            </div>
            <div>
               <p class="go_back"><a href="<?php echo admin_url("admin.php?page=malca-amit-shipping-service/template/order.php");?>"> &lt;&lt; Go Back </a></p>
            </div>
         </div>
      </div>
      <?php require_once('footer.php'); ?>