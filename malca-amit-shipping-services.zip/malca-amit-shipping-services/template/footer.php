<?php
   /* Template : Footer */

  // Exit if accessed directly.
  if ( ! defined( 'ABSPATH' ) ) {
    exit;
  }
   
   $image =plugins_url('../assets/images/logo.png',__FILE__);
   $cu = new WC_Countries();
   $concode = $cu->get_base_country();
   $malca = new MalcaAmitShippingService();
   $url = get_site_url();
   $store_url = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
   
   if($concode == "CA")
   {
    $term_url = 'https://express.malca-amit.ca/Application/Information/TermsAndConditions.html';
    $use_url = 'https://express.malca-amit.ca/Application/Information/TermsOfUse.html';
   
   }
   
   else
   {
    $term_url = 'https://express.malca-amit.us/Application/Information/TermsAndConditions.pdf';
    $use_url = 'https://express.malca-amit.us/Application/Information/TermsOfUse.html';
   
   }
   
   
   
   $info=$malca->malca_get_user_info($store_url);
   if($info['login_status'] == 1)
   {
     $faq_url=admin_url("admin.php?page=malca-amit-shipping-service/template/faq.php");
   }
   
   else
   {
     $faq_url=admin_url("admin.php?page=malca-amit-shipping-service/template/auth1.php");
   }
   
  
?>
<footer class="text-center">
   <div class="message">
      <p>A Malca-Amit specialist awaits your call to customize your solutions, contact us anytime.</p>
      <p><a href="mailto:Solutions@MyMalca.com" target="_parent"><strong>Solutions@MyMalca.com</strong></a> or <strong>1-844-MyMalca</strong></p>
   </div>
   <div class="img"><img src=" <?php echo $image;?>"/></div>
   <div class="footer_links">
      <ul>
         <li><a href="<?php echo $term_url ; ?>" target="_blank">Terms & Condition</a></li>
         <li><a href="<?php echo $use_url;?>" target="_blank">Terms of Use </a></li>
         <li><a href="https://express.malca-amit.us/Application/Information/PrivacyPolicy.html" target="_blank">Privacy Policy</a></li>
         <li><a href="<?php echo admin_url("admin.php?page=malca-amit-shipping-service/template/faq.php");?>" >FAQ</a>
         </li>
         <li class="singout_val"><a href="<?php echo admin_url("admin.php?page=malca-amit-shipping-service/template/index.php&action=logout");?>">Sign Out</a>
         </li>
      </ul>
   </div>
</footer>
</body>
</html>