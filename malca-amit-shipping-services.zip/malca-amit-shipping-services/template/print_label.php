<?php 

    // Exit if accessed directly.
    if ( ! defined( 'ABSPATH' ) ) {
      exit;
    }
   
   $malca_amit= new MalcaAmitShippingService();
   $var = wp_get_upload_dir();
   $root = $var['basedir'];
   $baseurl= $var['baseurl'];
   
   
   if(isset( $_GET['order_id'],$_GET['_wpnonce']))
   {
     $nonce=sanitize_text_field($_GET['_wpnonce']);
   
     if(!wp_verify_nonce($nonce,'malca_file_nonce'))
     {
       echo "Sothing went wrong.Nonce not decleare";
     }
     else{
   
       $orderId = sanitize_text_field($_GET['order_id']);
       $check_tracking_info = $malca_amit->malca_checkTracking($orderId);
       if ($check_tracking_info != 0) {
         $filename = $orderId."_Label.pdf";
         $urlfile =  $baseurl."/".$filename;  
         $response1 =admin_url("admin.php?page=malca-amit-shipping-service/template/request.php&file=$urlfile");
         wp_redirect($response1);
         wp_die();
       }
   
       else{
   
        $t=time();
        $curr_date=date("Y-m-d\TH:i:s",$t);
   
        $order_val = new WC_Order($orderId); 
        $url = get_site_url();
        $_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url); 
        $userinfo = $malca_amit->malca_get_user_info($_DOMAIN); 
        $username=$userinfo['username'];
        $password=$userinfo['password'];
        $stationcode=$userinfo['station_code'];
        $createddate=$order_val->get_date_created()->date( 'Y-m-d H:i:s' );
        $shipping_country_code=$order_val->get_shipping_country();
        $shipping_city=$order_val->get_shipping_city();
        $item_val=$order_val->get_items();   
        $total_val= $order_val->get_total();
        $shipping_method =$order_val->get_shipping_methods();
        $customer_firstname =$order_val->get_shipping_first_name();
        $customer_lastname= $order_val->get_shipping_last_name();
        $shipping_addressone=$order_val->get_shipping_address_1();
        $shipping_addresstwo=$order_val->get_shipping_address_2();
        $shipping_postcode=$order_val->get_shipping_postcode();
        $billingphonnum=$order_val->get_billing_phone();
        $billingemail=$order_val->get_billing_email();
        $statecode=$order_val->get_shipping_state();
        $cu = new WC_Countries();
        $base_country= $cu->get_base_country();
   
        foreach ($item_val as $item) {
   
         $product  = $order_val->get_product_from_item( $item );
   
         $weightval= wc_get_weight( $product->get_weight(), 'oz' );
         $qantity = $item->get_quantity();
         $weightval = $weightval*$qantity;
       } 
       foreach ($shipping_method as $shipping_val ) {
           // Replace non-AlNum characters with space
         $method_name = preg_replace( '/[^A-Za-z0-9 \-\.\_,]/', '', $shipping_val['name'] );      
       }
   
       $customer_full_name=$customer_firstname." ". $customer_lastname;
   
       $post_body = array('storeurl' => $_DOMAIN,'orderid'=>$orderId,'username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'odercreated_date'=>$createddate,'shipping_country'=>$shipping_country_code,'shipping_city'=>$shipping_city,'order_total'=>$total_val,'shipping_customer_firstname'=>$customer_firstname,'shipping_customer_lastname'=>$customer_lastname,'address_one'=>$shipping_addressone,'address_two'=>$shipping_addresstwo,'postcode'=>$shipping_postcode,'billing_number'=>$billingphonnum,'billing_email'=>$billingemail,'shipping_state'=>$statecode,'base_country_code'=>$base_country,'weightval'=>$weightval,'method_name'=>$method_name);
       $sendData = json_encode($post_body);
       $args = array(
         'body' => $sendData,
         'timeout' => '45',
         'headers' => array('Content-Type'=>'application/json;charset=UTF-8')
   
       );
   
       $response = wp_remote_post('https://mashopify.com/wordpressapp/download_label.php',$args);
       $output = wp_remote_retrieve_body($response);
   
       if ( is_wp_error( $response ) ) {
        $error_message = $response->get_error_message();
   
        $response1  = $error_message;
        echo $response1;
   
      } 
      else
      {
   
        $data = wp_json_encode($output);
        $data= json_decode($data);
        $data1 = substr($data,0,-1);
        $malaca_data = json_decode($data1,true);
   
        $status = $malaca_data['status'];
        if($status == 'error')
        {
   
   
          $iferror=$malaca_data['iferror'];
          $error_msg = $malaca_data['msg'];
          $text = $malaca_data['text'];
   
          if(empty( $error_msg ))
          {
            echo $error_msg ="0-".$text;
   
          }
          if($iferror!="Error")
          {
           $type_error="System Error";
           $message_error=$text;
         }
         else
         {
           $type_error="API Reply Error";
           $message_error= $error_msg;
         }
         $tokenval=$malca_amit->malca_get_access_token($_DOMAIN);
         $token = $tokenval['token'];
         $malca_amit->malca_error_mailsend($_DOMAIN,$token,$orderId,$type_error,$message_error,$stationcode, $username,$customer_firstname,$customer_lastname,$curr_date);
   
         echo "<h2 class=' Center'>Error with ".$error_msg."</h2>";
   
   
       }
       elseif($status == 'success')
       {
         $tracking_number = $malaca_data['tracking_number'];
         $filestream = $malaca_data['filestream'];
   
         $add_tracking_info = $malca_amit->malca_addTrackingInfo($orderId,$tracking_number);
         $status_order = $malca_amit->malca_fulfilment_status($orderId);
   
         $decoded = base64_decode($filestream);
   
         $filename=$orderId."_Label.pdf";
         $file = $root."/".$orderId."_Label.pdf";
         $url=$baseurl."/".$filename;
   
         file_put_contents($file, $decoded);
         if (file_exists($file)){
   
           $response1 = admin_url("admin.php?page=malca-amit-shipping-service/template/request.php&file=$url");
           wp_redirect($response1 );
   
         }
       }
     }
     echo $response1 ;
   }
   }
   }
   
?>