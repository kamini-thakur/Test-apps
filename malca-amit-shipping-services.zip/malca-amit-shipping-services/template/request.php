<?php

  // Exit if accessed directly.
   if ( ! defined( 'ABSPATH' ) ) {
     exit;
   }


   if(isset($_GET['file']))
   {
   $file = esc_url($_GET['file']);
   }
   else
   {
   $file='';	
   }
   
   if(isset($_GET['returnfile']))
   {
   	$retunfile =esc_url($_GET['returnfile']);
   
   }
   else
   {
   $retunfile ="";
   
   }
   
   $image = plugins_url('../assets/images/loader-v1.gif',__FILE__);
   ?>

<html>
   <head>
      <title></title>
   </head>
   <body>
      <a class="hidden orderdownload" href= "<?php echo $file ; ?>" download>label</a>
      <a class="hidden orderreturndownload" href= "<?php echo $retunfile ; ?>" download>label</a>
      <div class="modal fade" id="myownModal" role="dialog">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-body">
                  <p><img src="<?php echo $image ; ?>"/></p>
               </div>
            </div>
         </div>
      </div>
     
   </body>
</html>
 <script type="text/javascript">
         jQuery( document ).ready(function() {
            
            jQuery('#myownModal').modal('show');
            var href =jQuery('.orderdownload').attr('href');
            if(href!="")
            {
                jQuery('.orderdownload')[0].click(closewindow());
             
            }
            else
            {
         
             jQuery('.orderreturndownload')[0].click(closewindow());
         
            }
            
         });
         
         function closewindow()
         {
            setTimeout(function(){ 
               window.close(); 
            }, 2000);
         
         }
</script>     