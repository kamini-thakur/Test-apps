<?php

    // Exit if accessed directly.
    if ( ! defined( 'ABSPATH' ) ) {
      exit;
    }
    
   $malca_shipping= new MalcaAmitShippingService();
   $url = get_site_url();
   $store_url = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
   $userinfo =$malca_shipping->malca_get_user_info($store_url);  
   $username = $userinfo['username'];
   $password = $userinfo['password'];
   $stationcode =$userinfo['station_code'];
   
   if(isset($_GET['order_id'],$_GET['trackingnumber'],$_GET['_wpnonce']))
   {
     $nonce=$_GET['_wpnonce'];
   
     if(!wp_verify_nonce($nonce,'malca_file_nonce'))
     {
       echo "Sothing went wrong.Nonce not decleare";
     }
     else{
   
       $orderid =  sanitize_text_field($_GET['order_id']);
       $tracking_number =  sanitize_text_field($_GET['trackingnumber']);
   
       $var = wp_get_upload_dir();
       $root = $var['basedir'];
       $baseurl= $var['baseurl'];
   
   
       $post_body = array('username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'tracking_number'=> $tracking_number);
       $sendData = json_encode($post_body);
       $args = array(
         'body' => $sendData,
         'timeout' => '45',
         'headers' => array('Content-Type'=>'application/json;charset=UTF-8')
   
       );
   
       $response = wp_remote_post('https://mashopify.com/wordpressapp/return_data.php',$args);
       $output = wp_remote_retrieve_body($response);
   
         if ( is_wp_error( $response ) ) {
          $error_message = $response->get_error_message();
   
          $response1  = $error_message;
          echo $response1 ;
          }
   
          else
          {
           $data = wp_json_encode($output);
           $data= json_decode($data);
           $data1 = substr($data,0,-1);
           $malaca_data = json_decode($data1,true);
           $status = $malaca_data['status'];
   
           if($status == 'error')
           {
             $error_msg = $malaca_data['msg'];
             echo "<h2 class=' Center'>Error with ".$error_msg."</h2>";
   
             wp_die();  
           }
   
           elseif( $status == 'success')
           {
             $filestream = $malaca_data['filestream'];
             $decoded = base64_decode($filestream);
             $filename=$orderid."_ReturnLabel.pdf";
             $file = $root."/".$orderid."_ReturnLabel.pdf";
             $baseurlval = $baseurl."/".$filename;
             file_put_contents($file, $decoded);
             if (file_exists($file)){
               $var =admin_url("admin.php?page=malca-amit-shipping-service/template/request.php&returnfile=$baseurlval");
               wp_redirect($var);
   
             }
   
           }
           else{
             echo "error";
           }
       }
     }
   }
?>