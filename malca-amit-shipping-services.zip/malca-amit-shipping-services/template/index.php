<?php
  
  // Exit if accessed directly.
  if ( ! defined( 'ABSPATH' ) ) {
    exit;
  }
  

   $_DOMAIN= get_site_url();
   $_DOMAIN= preg_replace( "#^[^:/.]*[:/]+#i", "", $_DOMAIN ); 
   $malca = new MalcaAmitShippingService();
   
   $tokenvalue = $malca->malca_get_access_token($_DOMAIN);
   $access_token = $tokenvalue['token'];
   $login_status = $malca->malca_loginsingup_status_check($_DOMAIN);
   
   
   if ( isset( $_GET['action'] ) && $_GET['action'] == 'logout' )  
   {     
      $malca->malca_logout_status($_DOMAIN,$access_token);
       $malca->malca_logout($_DOMAIN);
        $redirect_url=admin_url("post.php?page=malca-amit-shipping-service/template/auth1.php");
       wp_redirect($redirect_url);
       exit();
   }
   
   if( $login_status['signup_status'] == 0 && $login_status['login_status'] == 0  )
   {
   
        $redirect_ur="admin.php?page=malca-amit-shipping-service/template/auth1.php";
       
          header("Location: $redirect_ur");
        exit();
   
    }
   
   
    else{
   
       if(isset( $login_status['login_status'] ) && $login_status['login_status'] == 1 )
         {
               $redirect_ur = "admin.php?page=malca-amit-shipping-service/template/order.php";
          header("Location: $redirect_ur");
          exit();
         }
   
        else{
        $redirect_ur="admin.php?page=malca-amit-shipping-service/template/singup_dashboard.php";
        header("Location: $redirect_ur");
        exit();   
        }
      
   
    }
       
