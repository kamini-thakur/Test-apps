<?php
   /*
   Template Name: order
   */
     
  // Exit if accessed directly.
  if ( ! defined( 'ABSPATH' ) ) {
    exit;
  }
  
   global $wpdb;
   $table_name = $wpdb->prefix ."orders_info"; 
   $ms = new MalcaAmitShippingService();
   $image = plugins_url('../assets/images/loader-v1.gif',__FILE__);

   
   $url = get_site_url();
   $shop_val = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
   $_DOMAIN = $shop_val;
   
   $cu = new WC_Countries();
   $concode = $cu->get_base_country();
   
   $customPagHTML ='';
   $per_page_item = 10;
   $total=$wpdb->get_var("SELECT COUNT(id) From $table_name");
   $page = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
   $offset =($page *$per_page_item ) - $per_page_item;
   $totalPage = ceil($total / $per_page_item);
   $outputval='';
   $orders = $wpdb->get_results("SELECT * From $table_name ORDER BY id DESC LIMIT $offset,$per_page_item ");
   //$rowcount = $orders->num_rows;
   if($orders){
   foreach ( $orders as $order_val) {
   
     $order_id = $order_val->order_id; 
     $id = $order_val->id; 
     $date = $order_val->Created_at;
     $date = date("M d,Y H:i a", strtotime($date));
     $total_price = $order_val->total_price;
     $total_price =number_format((float)$total_price, 2, '.', '');
     $customer_name = $order_val->customer_name;
     $countory_order = new WC_Order( $order_id);
     $country_code  = $countory_order->get_shipping_country();
     $orer_cahrge = $ms->malca_getShippingCharge($id);
     $status = $ms->malca_fulfilment_status($order_id);
     foreach ($orer_cahrge as $ordership) {
       $est_cost = $ordership->est_price;
       $est_cost =number_format((float)$est_cost, 2, '.', '');
       $tracking_code = $ordership->tracking_code;
       $order_status = $ordership->order_status;
       if($est_cost  != 'N/A')
       {
       if( $tracking_code != ''&& $concode == $country_code ) 
       {
        $button_val='<a class="hidden" id="order_idval-'.$order_id.'" href="" download> test</a><button data-toggle="modal" data-target="#myModal" class="btn btn-primary print-btn" onclick="malca_download_label('.$order_id.');">Print Label</button><button data-toggle="modal" data-target="#myModal" class="btn btn-primary print-btn" onclick="malca_return_label_download('.$order_id.','. $tracking_code .')">Return Label</button>';
      }
      else
      {
       $button_val = '<a class="hidden" href="" download> test</a><button data-toggle="modal" data-target="#myModal" class="btn btn-primary print-btn" onclick="malca_download_label('.$order_id.');">Print Label</button>';
     }
   
     $outputval .='<tr>
     <td class="orderNumber"><a target="_blank" href="'.admin_url('post.php?post= '.$order_id .'&action=edit').'">'.$order_id .'</td> 
     <td class="orderDate">'. $date .'</td>
     <td class="orderTracking-'.$order_id.'" id="trackig_val-'.$order_id.'">'. $tracking_code.'</td>
     <td class="orderCost"> $'.$est_cost.'  </td>
     <td class="orderCustomer"> '.$customer_name.'</td>
     <td class="orderTotal"> $'.  $total_price  .'</td>
     <td class="orderStatus">'. $order_status .'</td>
     <td class="Fulfilment-'.$order_id.'" id="statusval-'.$order_id.'">'.$status.' </td>
     <td id ="return_btn-'.$order_id.'"> '.$button_val.'</td>
     </tr>';
   
   }
   
   }
   
   } 
   }
   else
   {
     $outputval = '<td colspan="12">
                  <div class="text-center thankyou_page welcome_page">
                 <div class="text-center thankyou_page welcome_page">
                 <h2>Welcome to Malca Amit Shipping Services</h2>
                 <p class="center">
                   No Orders With Malca Amit  </p>
   
                   </div>
               </div>
               </td>
               </tr>';
   }
   if($totalPage > 1){
    $customPagHTML =  '<div><span></span>'.paginate_links( array(
       'base' => add_query_arg( 'cpage', '%#%' ),
       'format' => '',
       'prev_text' => __('Prev'),
       'next_text' => __('Next'),
       'total' => $totalPage,
       'current' => $page
     )).'</div>';
   }
   
   ?>
<!DOCTYPE html>
<html>
   <head></head>
   <body class="home_new">
      <div class="content container">
         <div class="col-sm-12 app_header">
            <div class="row">
               <div class="logo">
                  <div id="divPortalHeaderImage"></div>
               </div>
            </div>
         </div>
         <div class="page_content table-responsive">
            <div class="refresh_orders">
               <a class="btn-val" href="" data-toggle="modal" data-target="#myModal" id="refresh_button" ></a>
            </div>
            <ul class="tabs"  id='myTab'>
               <li class="active tab-link " ><a data-toggle="tab" href="#tab-1">Open</a></li>
               <li class="tab-link" ><a  data-toggle="tab" href="#tab-2">Filter</a></li>
            </ul>
            <!-- <div id="tab-1" class="tab-content"> -->
            <div id="tab-1" class="tab-content tab-pane fade in active">
               <table id= "mytable" class="table malcaordertable table-hover expanded " style="background:#fff;font-size:14px;font-weight: normal;" cellspacing="0" width="100%">
                  <thead>
                     <th class="is-sortable order">Order</th>
                     <th class="is-sortable date">Date</th>
                     <th class="is-sortable tcn">Tracking Number</th>
                     <th class="is-sortable customer">Est.Cost</th>
                     <th class="is-sortable customer">Customer</th>
                     <th class="is-sortable totalth">Total</th>
                     <th class="is-sortable text-center payment_status">Order Status</th>
                     <th class="is-sortable fullfilment">Fulfilment Status</th>
                     <th class="is-sortable fulfillment_status"></th>
                  </thead>
                  <tbody>  
                     <?php echo $outputval; ?>
                  </tbody>
               </table>
               <?php echo $customPagHTML;?>
            </div>
            <div id="tab-2" class="tab-content ab-pane fade ">
               <?php
                  $filter_output='';
                  
                  $pagination = '';
                  $order_output = '';
                  
                  global $wpdb;
                  $table_name = $wpdb->prefix ."orders_info";   
                  $item_per_page = 10;
                  $page = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 1;
                  $offset =($page *$item_per_page) - $item_per_page;
                  
                  
                  
                  if(isset($_GET['filter']))
                  {
                  
                    if(isset($_GET['filter1'],$_GET['filter2']) && $_GET['filter1'] == "date")
                    {
                  
                      $date_dynamic=$_GET['filter2'];
                  
                  
                      switch($date_dynamic) 
                      {
                  
                      case 'in_the_last_week':
                     $current_week = strtotime("-1 week +1 day");
                     $current_week1 =date("sunday midnight", $current_week);
                     $last_week =  date("+6 days",strtotime($current_week1 ));
                      break;
                  
                        case 'in_the_last_month':
                       $current_week1 = date('Y-m-01');
                       $last_week =  date("+30 days",strtotime($current_week1 ));
                        break;
                  
                        case 'in_the_last_year':
                       $current_week1 =date(strtotime('Y-01-01'));
                  
                       $last_week =  date(strtotime('Y-12-31'));
                        break;
                  
                      }
                  
                    $total = $wpdb->get_var("SELECT COUNT(id) From $table_name where Created_at >='".$current_week1."' AND Created_at <='".$last_week ."'");
                     $orders = $wpdb->get_results("SELECT * From $table_name  where Created_at <= '".$current_week1."' AND Created_at >='".$last_week ."' ORDER BY id DESC LIMIT $offset,$item_per_page");
                  
                          
                    }
                  
                    else if(isset($_GET['filter1'],$_GET['filter2']) && $_GET['filter1']=="status"){
                  
                      if($_GET['filter2'] != 'Any')
                     {
                      $total= $wpdb->get_var("SELECT COUNT(id) From $table_name where order_status = '".$_GET['filter2']."'");
                      $orders = $wpdb->get_results("SELECT * From $table_name  where order_status ='". $_GET['filter2']."' ORDER BY id DESC LIMIT $offset,$item_per_page");
                    }
                    else
                    {
                      $total= $wpdb->get_var("SELECT COUNT(id) From $table_name");
                      $orders = $wpdb->get_results("SELECT * From $table_name ORDER BY id DESC LIMIT $offset,$item_per_page");
                    }
                    
                  }
                  
                  
                  else if(isset($_GET['filter1']) && $_GET['filter1'] == -1){
                  
                    $total= $wpdb->get_var("SELECT COUNT(id) From $table_name");
                    $orders = $wpdb->get_results("SELECT * From $table_name  ORDER BY id DESC LIMIT $offset,$item_per_page");
                    
                  }
                  else if (isset($_GET['filter1'],$_GET['filter2']) && $_GET['filter1'] == 'fulfillment_status')
                  {
                    $total= $wpdb->get_var("SELECT COUNT(id) From $table_name where fulfilment_status = '".$_GET['filter2']."'");
                    $orders = $wpdb->get_results("SELECT * From $table_name where fulfilment_status = '".$_GET['filter2']."' ORDER BY id DESC LIMIT $offset,$item_per_page");   
                  }
                  
                  
                  }
                  
                  
                  if($orders){
                  foreach ( $orders as $order_val) {
                  
                  $order_id = $order_val->order_id; 
                  $id = $order_val->id; 
                  $date = $order_val->Created_at;
                  $date = date("M d,Y H:i a", strtotime($date));
                  $total_price  = $order_val->total_price;
                  $total_price =number_format((float)$total_price, 2, '.', '');
                  $countory_order = new WC_Order( $order_id);
                  $country_code  = $countory_order->get_shipping_country();
                  $customer_name = $order_val->customer_name;
                  
                  $orer_cahrge = $ms->malca_getShippingCharge($id);
                  $status = $ms->malca_fulfilment_status($order_id);
                  
                  foreach ($orer_cahrge as $ordership) {
                    $est_cost = $ordership->est_price;
                    $est_cost=number_format((float)$est_cost, 2, '.', '');
                    $tracking_code = $ordership->tracking_code;
                    $order_status = $ordership->order_status;
                    if( $tracking_code != '' &&  $concode == $country_code) 
                    {
                     $button_val='<a class="hidden" id="order_idval-'.$order_id.'" href="" download> test</a><button data-toggle="modal" data-target="#myModal"
                     class="btn btn-primary print-btn" onclick="malca_download_label('.$order_id.');">Print Label</button><button data-toggle="modal" data-target="#myModal" class="btn btn-primary print-btn" onclick="malca_return_label_download('.$order_id.','. $tracking_code .')">Return Label</button>';
                   }
                   else
                   {
                    $button_val = '<a class="hidden" id="order_idval-'.$order_id.'" href="" download> test</a><button data-toggle="modal" data-target="#myModal" class="btn btn-primary print-btn" onclick="malca_download_label('.$order_id.');">Print Label</button>';
                  }
                  
                  $order_output .='<tr>
                  <td class="orderNumber"><a target="_blank" href="'.admin_url('post.php?post= '.$order_id .'&action=edit').'">'.$order_id .'</td> 
                  <td class="orderDate">'. $date .'</td>
                  <td class="orderTracking-'.$order_id.'" >'. $tracking_code.'</td>
                  <td class="orderCost"> $'.$est_cost.'  </td>
                  <td class="orderCustomer"> '.$customer_name.'</td>
                  <td class="orderTotal"> $'. $total_price  .'</td>
                  <td class="orderStatus">'. $order_status .'</td>
                  <td class="Fulfilment-'.$order_id.'">'.$status.' </td>
                  <td id ="return_btn-'.$order_id.'"> '.$button_val.'</td>
                  </tr>';
                  
                  }
                  }
                  }
                  else {
                  
                  $order_output = '<td colspan="12">
                         <div class="text-center thankyou_page welcome_page">
                        <div class="text-center thankyou_page welcome_page">
                        <h2>Welcome to Malca Amit Shipping Services</h2>
                        <p class="center">
                          No Orders With Malca Amit  </p>
                  
                          </div>
                      </div>
                      </td>
                      </tr>';
                  
                  }
                  
                  if(isset($_GET['filter'],$_GET['filter1'],$_GET['filter2'])&& $_GET['filter1']=='fulfillment_status' && $_GET['filter2']==1)
                  {
                  
                  
                  $_GET['filter2'] = 'Fulfilled';
                  $filter_output .= "<p class='filter_select'>".str_replace('_',' ',$_GET['filter1'])." is ".str_replace('_',' ',$_GET['filter2'])."</p>";
                  }
                  else if (isset($_GET['filter'],$_GET['filter1'],$_GET['filter2'])&& $_GET['filter1']== 'fulfillment_status' && $_GET['filter2'] == 0)
                  {
                  $_GET['filter2'] = 'Unfulfilled';
                  $filter_output .= "<p class='filter_select'>".str_replace('_',' ',$_GET['filter1'])." is ".str_replace('_',' ',$_GET['filter2'])."</p>";
                  
                  }  
                  
                  else if(isset($_GET['filter'],$_GET['filter1'],$_GET['filter2'])&& $_GET['filter1'] && $_GET['filter2'])
                  {
                   $filter_output .= "<p class='filter_select'>".str_replace('_',' ',$_GET['filter1'])." is ".str_replace('_',' ',$_GET['filter2'])."</p>";
                  }
                  
                  
                  
                  $totalpageval = ceil($total / $item_per_page);
                    if($totalpageval > 1){ 
                  
                  
                  $pagination =  '<div><span></span>'.paginate_links( array(
                  'base' => add_query_arg( 'ppage', '%#%' ),
                  'format' => '',
                  'prev_text' => __('Prev'),
                  'next_text' => __('Next'),
                  'total' => $totalpageval,
                  'current' => $page
                  )).'</div>';
                  }
                  
                  ?>
                  
               <form method="GET" id="search_form"  action=''>
                  <input type="hidden" name="page" value="malca-amit-shipping-service/template/order.php">
                  <select id="filter1" name="filter1">
                     <option value="-1">Select a Filter...</option>
                     <option value="fulfillment_status">Fulfillment Status</option>
                     <option value="status">Order Status</option>
                     <option value="date">Date</option>
                  </select>
                  <select id="filter2" name="filter2" style="display:none;">
                  </select>
                  <input type="submit" name="filter" class="btn-primary filterload" value="Add Filter">
               </form>
               <?php echo  $filter_output; ?> 
               <table id= "mytable" class="table malcaordertable table-hover expanded " style="background:#fff;font-size:14px;font-weight: normal;" cellspacing="0" width="100%">
                  <thead>
                     <th class="is-sortable order">Order</th>
                     <th class="is-sortable date">Date</th>
                     <th class="is-sortable tcn">Tracking Number</th>
                     <th class="is-sortable customer">Est.Cost</th>
                     <th class="is-sortable customer">Customer</th>
                     <th class="is-sortable totalth">Total</th>
                     <th class="is-sortable text-center payment_status">Order Status</th>
                     <th class="is-sortable fullfilment">Fulfilment Status</th>
                     <th class="is-sortable fulfillment_status"></th>
                  </thead>
                  <tbody>  
                     <?php echo $order_output;?> 
                  </tbody>
               </table>
               <?php echo $pagination;?>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="myModal" role="dialog">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <div class="modal-body">
                        <p><img class="imgurl" src="<?php echo $image ; ?>"/></p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
	   
	   <input type="hidden" value="<?php echo $image; ?>" id="loader-url" >
	   
      <?php require_once('footer.php'); ?>