<?php

   /**
    * Plugin Name: Malca-Amit Shipping Services
    * Plugin URI: http://www.malca-amit.com
    * Description: Full Shipping Integration with FedEx, UPS and USPS.
    * Version: 1.0
    * Author: Malca Amit 
    * Author URI: http://www.malca-amit.com/
    * License: GPLv2 or later
    * License URI: http://www.malca-amit.com/
    * Text Domain: malca-amit-shipping-services
    * WC requires at least: 2.2.0
    * WC tested up to: 3.2.0
    */


    // Exit if accessed directly.
    if ( ! defined( 'ABSPATH' ) ) {
      exit;
    }

   
   if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
   
     if ( ! defined( 'MALCAAMIT_DIR' ) ) {
       define('MALCAAMIT_DIR', plugin_dir_path(__FILE__)); 
     }
   
   
   
     include_once(MALCAAMIT_DIR . 'include/function.php');
     include_once(MALCAAMIT_DIR . 'include/init.php');
     
   
     /* activation of plugin */
     function malca_activate()
     {
   
      $malca = new  MalcaAmitShippingService();
   
      $url = get_site_url();
      $_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
   
      $token = md5(uniqid(rand(), true));
   
      global $wpdb; 
      $table_name_info = $wpdb->prefix . "malca_user_info";
      $charset_collate = $wpdb->get_charset_collate();
      $curr_date = date('Y-m-d H:i:s');
   
      include_once( ABSPATH .'wp-admin/includes/upgrade.php');
   
   
      /* create malca_user_info table */
   
      $sql = "CREATE TABLE IF NOT EXISTS $table_name_info(
   
      id int(11) NOT NULL AUTO_INCREMENT,
      shop_domain varchar(255) DEFAULT '' NOT NULL,
      token varchar(255) DEFAULT '' NOT NULL,
      token_status int(11) DEFAULT '0',
      signup_status int(11) DEFAULT '0',
      username varchar(255) DEFAULT '' NOT NULL,
      password varchar(255) DEFAULT '' NOT NULL,
      station_code varchar(255) DEFAULT '' NOT NULL,
      login_status int(11) DEFAULT '0',
      created_at DATETIME DEFAULT NULL,
      PRIMARY KEY (id) ) $charset_collate; ";
   
      dbDelta($sql);
   
   
      $select_query = $wpdb->get_var("SELECT COUNT(id) From $table_name_info WHERE shop_domain ='".$_DOMAIN ."'");
   
      if($select_query == 0)
      {
   
        $sql_insert_url = $wpdb->insert($table_name_info, array('shop_domain' => $_DOMAIN,'token'=> $token,'created_at'=>$curr_date));
        dbDelta($sql_insert_url);
        if($sql_insert_url)
        {
          $tokenvalue = $malca->malca_get_access_token($_DOMAIN);
          $access_token = $tokenvalue['token'];
          $currn_date =  $tokenvalue['created_at'];
          $malca->malca_install_details($_DOMAIN,$access_token,$currn_date);
   
        }
   
      }
      else
      {
       $tokenvalue = $malca->malca_get_access_token($_DOMAIN);
       $access_token = $tokenvalue['token'];
       $malca->malca_install_status_upadte($_DOMAIN,$access_token);
     }
   
   
     /* create order_info table for plugin */
   
     $table_name = $wpdb->prefix . "orders_info";
     $sql_query = "CREATE TABLE IF NOT EXISTS $table_name(
   
     id int(11) NOT NULL AUTO_INCREMENT,
     order_id varchar(30) NOT NULL,
     customer_name varchar(255) DEFAULT '' NOT NULL,
     total_price varchar(255) NOT NULL,
     shop_domain varchar(100) DEFAULT '' NOT NULL,
     est_price varchar(255) DEFAULT '' NOT NULL,
     tracking_code varchar(50) DEFAULT NULL,
     fulfilment_status int(11) DEFAULT '0' COMMENT '0 - unfulfil status, 1 - fulfil status',
     order_status varchar(255) DEFAULT NULL,
     order_completed int(11) NOT NULL DEFAULT '0',
     Created_at DATETIME DEFAULT NULL,
	 PRIMARY KEY(id),
     UNIQUE KEY `orderid` (order_id,shop_domain)) $charset_collate; ";
     dbDelta( $sql_query);
   
     wp_schedule_event( time(), 'five-minitue', 'malca_order_cron_job' );
   
   }
   
   register_activation_hook( __FILE__, 'malca_activate');
   
   
   /* Cron job for update the order status  in order table */
   
   add_action( 'malca_order_cron_job',  'malca_order_update_message' );
   
   function  malca_order_update_message()
   {
   
     $ma = new MalcaAmitShippingService();
     $var = $ma->malca_update_shipment();
   
   
   }
   
   add_filter( 'cron_schedules', 'malca_add_new_cron_schedule' );
   
   
   /* Schedule the cron job after 5 miniuts it run atomatically*/ 
   function malca_add_new_cron_schedule( $schedules )
   {
    $schedules['five-minitue'] = array ( 'interval' => 300,
      'display'  => 'Every 300 Seconds' );
    return $schedules;
   }
   
   add_action( 'wp_footer', 'malca_display_cron_jobs' );
   function malca_display_cron_jobs()
   {
    $cron = _get_cron_array();
    
   }
   
   /* Deacitve the plugin */
   register_deactivation_hook( __FILE__,'malca_deactivate');
   function malca_deactivate() {
       
	 global $wpdb;
     $table_name = $wpdb->prefix . "orders_info";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query( $sql );
	   
	 $table_name = $wpdb->prefix . "malca_user_info";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query( $sql );
	   
     $url = get_site_url();
     $_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
     $malca = new  MalcaAmitShippingService();
     $tokenvalue = $malca->malca_get_access_token($_DOMAIN);
     $access_token = $tokenvalue['token'];
     $malca->malca_install_status($_DOMAIN,$access_token);
   
   
     $time = wp_next_scheduled( 'malca_cron_hook_value' );
     wp_unschedule_event( $time, 'malca_cron_hook_value' );
     
   
   }
   
   
   /* Unstalltion process  of  the plugin */
   register_uninstall_hook( __FILE__, 'malca_uninstall');
   function malca_uninstall() {
   
     global $wpdb;
     $table_name = $wpdb->prefix . "orders_info";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query( $sql );
   
   
     $table_name = $wpdb->prefix . "malca_user_info";
     $sql = "DROP TABLE IF EXISTS $table_name;";
     $wpdb->query( $sql );
   
   
   }
   
   
   
   /* order create functionality */
   
   add_action('woocommerce_checkout_order_processed','malca_call_order');
   function malca_call_order($order_id)
   { 
   
     $url = get_site_url();
     $_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
     $ma = new MalcaAmitShippingService();
     $details=$ma->malca_get_user_info($_DOMAIN);
     $username =  $details['username'];
     if(isset($username))
     {
      $var = $ma->malca_get_cost_from_order($order_id);  
   
   
    }
   
   }
   
   add_action('admin_enqueue_scripts', 'malca_my_enqueue');
   
   function malca_my_enqueue() {
   
   
     wp_enqueue_script( 'ajax-script', plugins_url( 'assets/js/malca_amit.js', __FILE__ ),array( 'jquery' ));
     $title_nonce = wp_create_nonce( 'malca_example' );
     wp_localize_script( 'ajax-script', 'my_ajax_obj', array('ajax_url' => admin_url( 'admin-ajax.php' ),'nonce'  => $title_nonce,
   ) );
   }
   
   add_action('admin_enqueue_scripts', 'malca_cstm_css_and_js');
   function malca_cstm_css_and_js($hook) {
   
    if ("admin_page_malca-amit-shipping-service/template/auth1"!= $hook && "admin_page_malca-amit-shipping-service/template/order"!= $hook  && "admin_page_malca-amit-shipping-service/template/singup_dashboard"!= $hook && "admin_page_malca-amit-shipping-service/template/faq"!= $hook && "admin_page_malca-amit-shipping-service/template/request"!= $hook) {
      return;
    }
//wp_die($hook);
   wp_enqueue_style( 'bootstrap_style', plugins_url('assets/css/bootstrap.min.css',__FILE__));
   wp_enqueue_script( 'malca_script', plugins_url('assets/js/bootstrap.min.js',__FILE__),array( 'jquery' ));
   wp_enqueue_style( 'new_style', plugins_url('assets/css/new_style.css',__FILE__));
   wp_enqueue_style( 'style', plugins_url('assets/css/style.css',__FILE__));
   wp_enqueue_style( 'normalize', plugins_url('assets/css/normalize.css',__FILE__));
   wp_enqueue_style( 'font-awesome',  plugins_url('assets/css/font-awesome.css',__FILE__));
   wp_enqueue_script( 'new_malca-script', plugins_url( 'assets/js/new_malca_file.js', __FILE__ ),array( 'jquery' )); 
   
   }
   
   
   
   
   add_action('admin_menu','malca_order_menu');
   
   function malca_order_menu(){
   
     $image = plugins_url('malca-amit-shipping-services/assets/images/malca_logo.png');
     add_menu_page('Malca Amit', 'Malca-Amit', 'manage_options','malca-amit-shipping-service/template/index.php','main_menu_function' ,$image ,'', 6);
     add_submenu_page(null,'User','user', 'manage_options','malca-amit-shipping-service/template/auth1.php' , 'submenu_function1','', 0 );
     add_submenu_page(null, 'Singupboard','singupboard', 'manage_options','malca-amit-shipping-service/template/singup_dashboard.php' , 'submenu_function2','', 0); 
   
     add_submenu_page(null, 'Order','Order', 'manage_options','malca-amit-shipping-service/template/order.php' , 'submenu_function3','', 6 );
     add_submenu_page(null, 'FAQ','AQ', 'manage_options','malca-amit-shipping-service/template/faq.php' , 'submenu_function4','', 6 );
     add_submenu_page(null, 'Print','print', 'manage_options','malca-amit-shipping-service/template/print_label.php' , 'submenu_function5','', 6 ); 
     add_submenu_page(null, 'return','return', 'manage_options','malca-amit-shipping-service/template/return_label.php' , 'submenu_function6','', 6 ); 
     add_submenu_page(null, 'Request','request', 'manage_options','malca-amit-shipping-service/template/request.php' , 'submenu_function7','', 6 );   
   
   }

   function  main_menu_function(){
      include_once(MALCAAMIT_DIR . 'template/index.php');
   }
   
   function  submenu_function1(){
    include_once(MALCAAMIT_DIR . 'template/auth1.php');
   }  

   function  submenu_function2(){
    include_once(MALCAAMIT_DIR . 'template/singup_dashboard.php');
   }

   function  submenu_function3(){
    include_once(MALCAAMIT_DIR . 'template/order.php');
   }
   function  submenu_function4(){
    include_once(MALCAAMIT_DIR . 'template/faq.php');
   }
   function  submenu_function5(){
    include_once(MALCAAMIT_DIR . 'template/print_label.php');
   }
   function  submenu_function6(){
    include_once(MALCAAMIT_DIR . 'template/return_label.php');
   }
   function  submenu_function7(){
    include_once(MALCAAMIT_DIR . 'template/request.php');
   }
   
   }
   
   
   else
   {
    add_action( 'admin_notices', 'malca_install_woocommerce_admin_notice' );
   
    if( ! function_exists( 'malca_install_woocommerce_admin_notice' ) ) {
     function malca_install_woocommerce_admin_notice() {
       ?>
<div class="error">
   <p><?php _e( 'For Malca-Amit shipping Service plugin you needs to Activate/Install Woocommerce.' ); ?></p>
</div>
<?php
}
}
}