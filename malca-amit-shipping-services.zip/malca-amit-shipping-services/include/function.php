<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class MalcaAmitShippingService
{


public function malca_install_details($_DOMAIN,$token,$date)
{
$post_body  = array('rquest'=>'insert_data','storeurl' => $_DOMAIN,'created_at'=>$date);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
$output=wp_remote_retrieve_body($response);
$data = json_decode($output,true);
if($data['success'] == 1)
{
global $wpdb; 
$table_name_info = $wpdb->prefix ."malca_user_info";
$query = $wpdb->query($wpdb->prepare("UPDATE $table_name_info SET token_status = 1 WHERE  shop_domain = '".$_DOMAIN."'"));
}
}


public function malca_submit_logindetails($_DOMAIN,$token,$username,$password,$station_code)
{
$post_body = array('rquest'=>'login_details','storeurl' => $_DOMAIN,'username'=>$username,'password'=>$password,'station_code'=>$station_code);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
}


public function malca_logout_status($_DOMAIN,$token)
{
$post_body = array('rquest'=>'logout_status','storeurl' =>$_DOMAIN);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
}


public function malca_install_status($_DOMAIN,$token)
{
$post_body = array('rquest'=>'install_status','storeurl' =>$_DOMAIN);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
}


public function malca_install_status_upadte($_DOMAIN,$token)
{
$post_body = array('rquest'=>'update_install_status','storeurl' =>$_DOMAIN);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
}


public function malca_sinup_mail($_DOMAIN,$token,$company_name,$companywebsite,$contactperson,$phone,$emailsignup)
{
$post_body = array('rquest'=>'send_mail','storurl' =>$_DOMAIN,'company_name'=>$company_name,'company_web'=>$companywebsite,'contact_person'=>$contactperson,'phone'=>$phone,'email'=>$emailsignup);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
$output=wp_remote_retrieve_body($response);
$data = json_decode($output,true);
if($data['success'] == "1")
{
global $wpdb;
$table_name = $wpdb->prefix ."malca_user_info"; 
$update_tracking = $wpdb->query($wpdb->prepare("UPDATE $table_name SET signup_status = 1  WHERE shop_domain ='".$_DOMAIN ."'"));
return "success";
}  
else
{
return "error";
}
}


public function malca_error_mailsend($_DOMAIN,$token,$order_id,$type_error, $message_error,$station_code,$username,$firstname,$lastname,$curr_date)
{
$post_body = array('rquest'=>'error_mail','storurl' =>$_DOMAIN,'order_id'=>$order_id,'type_error'=>$type_error,'message_error'=>$message_error,'staion_code'=>$station_code,'username'=>$username,'firstname'=>$firstname,'lastname'=>$lastname,'curr_date'=>$curr_date);
$args = array(
'body' => $post_body,
'timeout' => '5',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/api.php',$args);
$output=wp_remote_retrieve_body($response);
$data = json_decode($output,true);
if($data['success'] == "1")
{
$result = $data['msg'];
}  
return  $result;
}


public function malca_auth_malcauser($_DOMAIN,$username,$password,$stationcode,$token)
{    
$post_body = array('rquest'=>'auth_malcauser','storurl' =>$_DOMAIN,'username'=>$username,'password'=>$password,'stationcode'=>$stationcode);
$args = array(
'body' => $post_body,
'timeout' => '45',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/printapi.php',$args);
$output=wp_remote_retrieve_body($response);
// $data = json_encode($output);
$data = json_decode($output,true);
$code = $data['code'];
return  $code ;
}


/* function to parse Amit Malca response
Usage for the function
list ($notification_type, $message) = parse_return($response); 
*/
public function malca_setUserInfo($_DOMAIN,$username,$password,$stationcode)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$query = $wpdb->query("UPDATE $table_name SET username='".$username."' , password='".$password."', station_code ='".$stationcode."' WHERE  shop_domain = '".$_DOMAIN ."'");
if($query) 
{
return "datasave";
} 
}


public function malca_get_user_info($_DOMAIN)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$row = $wpdb->get_row("SELECT * From $table_name WHERE shop_domain ='".$_DOMAIN ."'",ARRAY_A);
return $row;
}


public function malca_login_status($_DOMAIN)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$query = $wpdb->query("UPDATE $table_name SET login_status = 1 WHERE  shop_domain = '".$_DOMAIN ."'");
if($query)
{
return "success";
}
else
return "error";
}


public function malca_get_access_token($_DOMAIN)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$row = $wpdb->get_row("SELECT * From $table_name WHERE shop_domain ='".$_DOMAIN."'",ARRAY_A);
return $row;
}


public function malca_loginsingup_status_check($_DOMAIN)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$row = $wpdb->get_row("SELECT * From $table_name WHERE shop_domain ='".$_DOMAIN ."'",ARRAY_A);
return $row;
}


public function malca_logout($_DOMAIN)
{
global $wpdb;
$table_name = $wpdb->prefix . "malca_user_info";
$query = $wpdb->query("UPDATE $table_name SET signup_status=0,login_status = 0 WHERE  shop_domain = '".$_DOMAIN ."'");
if($query)
{
return "success";
}
else
return "error";
}


public function malca_getOpenOrders()
{
global $wpdb;
$table_name = $wpdb->prefix . "orders_info";
$row = $wpdb->get_results("SELECT * FROM $table_name where tracking_code != '' and order_completed = 0");
return $row;
}


public function malca_updateOrder($msg,$_DOMAIN,$order_id)
{
global $wpdb;
$table_name = $wpdb->prefix . "orders_info";
if ($msg == 'completed') {
$update_tracking = $wpdb->query("UPDATE $table_name SET order_status='".$msg."', order_completed = 1 WHERE shop_domain = '".$_DOMAIN."' and order_id = '".$order_id."'");
}
else
{
$update_tracking = $wpdb->query("UPDATE $table_name SET order_status='".$msg."' WHERE shop_domain ='".$_DOMAIN."' and order_id = '".$order_id."'");  
}
if ($update_tracking) { 
return "success";
} 
else {
return "error";
}
}


public function malca_update_shipment()
{
try {
$all_orders = $this->malca_getOpenOrders();
if ($all_orders != 'No Results Found') {
foreach ($all_orders as $order_details) 
{ 
$users_data = $this->malca_get_user_info($order_details->shop_domain);
$username= $users_data['username'];
$password =$users_data['password'];
$stationcode=$users_data['station_code'];
$token = $users_data['token'];
$trackingnumber =$order_details->tracking_code;
$post_body = array('rquest'=>'update_shipment_status','username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'tracking_number'=>$trackingnumber);
$args = array(
'body' => $post_body,
'timeout' => '45',
'redirection' => '5',
'blocking' => true,
'headers' => array("Token" => $token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/printapi.php',$args);
$output=wp_remote_retrieve_body($response);
$data = json_decode($output,true);
$status= $data['status'];
if (strtoupper($status) == "SUCCESS") {
$message = $data['msg'];
$alter_message = str_replace(' ', '_', $message);
switch ($alter_message) {
case 'In_Transit':
$mess = "in_transit";
break;
case 'Out_for_Delivery':
$mess = "out_for_delivery";
break;
case 'Delivered':
$mess = "completed";
break;
case 'Failure':
$mess = "failure";
break;
case 'Shipment_Canceled':
$mess = "failure";
break;  
case 'Shipment_cancelled_by_sender':
$mess = "cancel";
break;
default:
$mess = "pending";
}
if ($order_details->order_status != $mess) {
$update_order_data = $this->malca_updateOrder($mess, $order_details->shop_domain, $order_details->order_id );
if ($mess == "completed") {
$statusorder = new WC_Order($order_details->order_id);
$statusorder->malca_update_status('completed');
}      
}
}
}
return  $mess  ;
}
}
catch(Exception $e) {
return 'Message: ' .$e->getMessage();
}
}


public  function malca_estcostdata($order_id,$customer_name,$total_price,$_DOMAIN,$est_price,$createddate)
{
global $wpdb;
$table_name = $wpdb->prefix . "orders_info"; 
$wpdb->insert($table_name, array('order_id' =>$order_id,'customer_name'=>$customer_name,'total_price'=>$total_price,'shop_domain'=>$_DOMAIN,'est_price' =>$est_price, 'Created_at'=> $createddate));
}


public function malca_get_cost_from_order($order_id)
{
$order_val = new WC_Order($order_id); 
$url = get_site_url();
$_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url); 
$userinfo = $this->malca_get_user_info($_DOMAIN); 
$username=$userinfo['username'];
$password=$userinfo['password'];
$stationcode=$userinfo['station_code'];
$createddate=$order_val->get_date_created()->date( 'Y-m-d H:i:s' );
$shipping_country_code=$order_val->get_shipping_country();
$shipping_city=$order_val->get_shipping_city();
$item_val=$order_val->get_items();   
$total_val= $order_val->get_total();
$shipping_method =$order_val->get_shipping_methods();
$customer_firstname =$order_val->get_shipping_first_name();
$customer_lastname= $order_val->get_shipping_last_name();
$shipping_addressone=$order_val->get_shipping_address_1();
$shipping_addresstwo=$order_val->get_shipping_address_2();
$shipping_postcode=$order_val->get_shipping_postcode();
$billingphonnum=$order_val->get_billing_phone();
$billingemail=$order_val->get_billing_email();
$statecode=$order_val->get_shipping_state();
$cu = new WC_Countries();
$base_country= $cu->get_base_country();
foreach ($item_val as $item) {
$product  = $order_val->get_product_from_item( $item );
$weightval= wc_get_weight( $product->get_weight(), 'oz' );
$qantity = $item->get_quantity();
$weightval = $weightval*$qantity;
} 
foreach ($shipping_method as $shipping_val ) {
// Replace non-AlNum characters with space
$method_name = preg_replace( '/[^A-Za-z0-9 \-\.\_,]/', '', $shipping_val['name'] );      
}
$customer_full_name=$customer_firstname." ". $customer_lastname;
$post_body = array('storeurl' => $_DOMAIN,'orderid'=>$order_id,'username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'odercreated_date'=>$createddate,'shipping_country'=>$shipping_country_code,'shipping_city'=>$shipping_city,'order_total'=>$total_val,'shipping_customer_firstname'=>$customer_firstname,'shipping_customer_lastname'=>$customer_lastname,'address_one'=>$shipping_addressone,'address_two'=>$shipping_addresstwo,'postcode'=>$shipping_postcode,'billing_number'=>$billingphonnum,'billing_email'=>$billingemail,'shipping_state'=>$statecode,'base_country_code'=>$base_country,'weightval'=>$weightval,'method_name'=>$method_name);
$sendData = json_encode($post_body);
$args = array(
'body' => $sendData,
'timeout' => '45',
'headers' => array('Content-Type'=>'application/json;charset=UTF-8')
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/mytest.php',$args);
$output = wp_remote_retrieve_body($response);
if ( is_wp_error( $response ) ) {
$error_message = $response->get_error_message();
$response1  = $error_message;
} else {
$data  = wp_json_encode($output);
$val = json_decode($data);
$esti_price = json_decode($val,true);
$response1  = $esti_price['total_price'];
$this->malca_estcostdata($order_id,$customer_full_name, $total_val,$_DOMAIN,$response1,$createddate);
}
return  $response1 ;
}


public function malca_getShippingCharge($id)
{
global $wpdb;
$table_name = $wpdb->prefix ."orders_info"; 
$row = $wpdb->get_results("SELECT * From $table_name WHERE id = $id");
return $row;
}


public function malca_addTrackingInfo($orderId,$tracking_code)
{
global $wpdb;
$table_name = $wpdb->prefix ."orders_info"; 
$update_tracking = $wpdb->query("UPDATE $table_name SET  tracking_code=".$tracking_code." ,fulfilment_status = 1  WHERE order_id = $orderId");
if ($update_tracking) { 
return "success";
} else {
return "error";
}
}


public function malca_checkTracking($orderId)
{
global $wpdb;
$table_name = $wpdb->prefix ."orders_info"; 
$tracking_code = $wpdb->get_row("SELECT * From $table_name WHERE order_id ='".$orderId ."'",ARRAY_A);
$trackingnumber= $tracking_code['tracking_code'];
if($trackingnumber!== NULL)
{
return $trackingnumber;
}
else {
return "error";
}
}


public function malca_fulfilment_status($orderId)
{
global $wpdb;
$table_name = $wpdb->prefix ."orders_info"; 
$sql = $wpdb->get_results("SELECT * FROM  $table_name  WHERE order_id = $orderId");
foreach ($sql as $value)
{
$tracking_status = $value->fulfilment_status;
}
if($tracking_status!= 0)
{
return 'Fulfilled';
}
else
{
return 'Unfulfilled';
}
}
}