<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
exit;
}


/*  Download functioanlity for shippment */
add_action("wp_ajax_malca_print_label", "malca_print_label");
add_action("wp_ajax_nopriv_malca_print_label", "malca_print_label");

function malca_print_label()
{
$malca_amit= new MalcaAmitShippingService();
$var = wp_get_upload_dir();
$root = $var['basedir'];
$baseurl= $var['baseurl'];
if(isset($_POST['id']))
{ 
$orderId=sanitize_text_field($_POST['id']);
$check_tracking_info = $malca_amit->malca_checkTracking($orderId);
if ($check_tracking_info != 0) {
$filename = $orderId."_Label.pdf";
$urlfile =  $baseurl."/".$filename;
$response1 = array('status'=> 'success', 'msg'=>$filename , 'tracking_number'=>$check_tracking_info,'base_url'=>$urlfile);
echo json_encode($response1);
//wp_die();
}
else{
$t=time();
$curr_date=date("Y-m-d\TH:i:s",$t);
$order_val = new WC_Order($orderId); 
$url = get_site_url();
$_DOMAIN = preg_replace( "#^[^:/.]*[:/]+#i", "", $url); 
$userinfo = $malca_amit->malca_get_user_info($_DOMAIN); 
$username=$userinfo['username'];
$password=$userinfo['password'];
$stationcode=$userinfo['station_code'];
$createddate=$order_val->get_date_created()->date( 'Y-m-d H:i:s' );
$shipping_country_code=$order_val->get_shipping_country();
$shipping_city=$order_val->get_shipping_city();
$item_val=$order_val->get_items();   
$total_val= $order_val->get_total();
$shipping_method =$order_val->get_shipping_methods();
$customer_firstname =$order_val->get_shipping_first_name();
$customer_lastname= $order_val->get_shipping_last_name();
$shipping_addressone=$order_val->get_shipping_address_1();
$shipping_addresstwo=$order_val->get_shipping_address_2();
$shipping_postcode=$order_val->get_shipping_postcode();
$billingphonnum=$order_val->get_billing_phone();
$billingemail=$order_val->get_billing_email();
$statecode=$order_val->get_shipping_state();
$cu = new WC_Countries();
$base_country= $cu->get_base_country();
$tokenval=$malca_amit->malca_get_access_token($_DOMAIN);
$token = $tokenval['token'];
foreach ($item_val as $item) {
$product  = $order_val->get_product_from_item( $item );
$weightval= wc_get_weight( $product->get_weight(), 'oz' );
$qantity = $item->get_quantity();
$weightval = $weightval*$qantity;
} 
foreach ($shipping_method as $shipping_val ) {
// Replace non-AlNum characters with space
$method_name = preg_replace( '/[^A-Za-z0-9 \-\.\_,]/', '', $shipping_val['name'] );      
}
$customer_full_name=$customer_firstname." ". $customer_lastname;
$post_body = array('storeurl' => $_DOMAIN,'orderid'=>$orderId,'username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'odercreated_date'=>$createddate,'shipping_country'=>$shipping_country_code,'shipping_city'=>$shipping_city,'order_total'=>$total_val,'shipping_customer_firstname'=>$customer_firstname,'shipping_customer_lastname'=>$customer_lastname,'address_one'=>$shipping_addressone,'address_two'=>$shipping_addresstwo,'postcode'=>$shipping_postcode,'billing_number'=>$billingphonnum,'billing_email'=>$billingemail,'shipping_state'=>$statecode,'base_country_code'=>$base_country,'weightval'=>$weightval,'method_name'=>$method_name);
$sendData = json_encode($post_body);
$args = array(
'body' => $sendData,
'timeout' => '45',
'headers' => array('Content-Type'=>'application/json;charset=UTF-8','Token'=>$token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/download_label.php',$args);
$output = wp_remote_retrieve_body($response);
if ( is_wp_error( $response ) ) {
$error_message = $response->get_error_message();
$response1  = $error_message;
} 
else
{
$data = wp_json_encode($output);
$data= json_decode($data);
$data1 = substr($data,0,-1);
$malaca_data = json_decode($data1,true);
$status = $malaca_data['status'];
if($status == 'error')
{
$iferror=$malaca_data['iferror'];
$error_msg = $malaca_data['msg'];
$text = $malaca_data['text'];
if(empty( $error_msg ))
{
echo $error_msg ="0-".$text;
}
if($iferror!="Error")
{
$type_error="System Error";
$message_error=$text;
}
else
{
$type_error="API Reply Error";
$message_error= $error_msg;
}
$malca_amit->malca_error_mailsend($_DOMAIN,$token,$orderId,$type_error,$message_error,$stationcode, $username,$customer_firstname,$customer_lastname,$curr_date);
$response1= array('status'=> $status, 'msg'=>$error_msg);
$response1=json_encode($response1);
}
elseif($status == 'success')
{
$tracking_number = $malaca_data['tracking_number'];
$filestream = $malaca_data['filestream'];
$add_tracking_info = $malca_amit->malca_addTrackingInfo($orderId,$tracking_number);
$status_order = $malca_amit->malca_fulfilment_status($orderId);
$decoded = base64_decode($filestream);
$filename=$orderId."_Label.pdf";
$file = $root."/".$orderId."_Label.pdf";
$url=$baseurl."/".$filename;
file_put_contents($file, $decoded);
if (file_exists($file)){
// echo $filename;
$response1 = array('status'=> 'success', 'msg'=>$filename,'tracking_number'=>$tracking_number,'base_url'=>$url,'order_status'=>$status_order);
$response1=json_encode($response1);
}
}
}
echo $response1 ;
}
}
}


/* code for retunlabel */
add_action("wp_ajax_malca_return_label", "malca_return_label");
add_action("wp_ajax_nopriv_malca_return_label", "malca_return_label");

function malca_return_label()
{
$malca_shipping= new MalcaAmitShippingService();
$url = get_site_url();
$store_url = preg_replace( "#^[^:/.]*[:/]+#i", "", $url ); 
$userinfo =$malca_shipping->malca_get_user_info($store_url);  
$username = $userinfo['username'];
$password = $userinfo['password'];
$stationcode =$userinfo['station_code'];
$token =$userinfo['token'];
if(isset($_POST['id']) && isset($_POST['trackingnumber']))
{
$orderid = sanitize_text_field($_POST['id']);
$tracking_number = sanitize_text_field($_POST['trackingnumber']);
$var = wp_get_upload_dir();
$root = $var['basedir'];
$baseurl= $var['baseurl'];
$post_body = array('username'=>$username,'password'=>$password,'stationcode'=>$stationcode,'tracking_number'=> $tracking_number);
$sendData = json_encode($post_body);
$args = array(
'body' => $sendData,
'timeout' => '45',
'headers' => array('Content-Type'=>'application/json;charset=UTF-8','Token'=>$Token)
);
$response = wp_remote_post('https://mashopify.com/wordpressapp/return_data.php',$args);
$output = wp_remote_retrieve_body($response);
if ( is_wp_error( $response ) ) {
$error_message = $response->get_error_message();
$response1  = $error_message;
}
else{
$data = wp_json_encode($output);
$data= json_decode($data);
$data1 = substr($data,0,-1);
$malaca_data = json_decode($data1,true);
$status = $malaca_data['status'];
if($status == 'error')
{
$error_msg = $malaca_data['msg'];
$response1 = array('status'=> 'error','msg'=>$error_msg);
$response1= json_encode($response1);
}
elseif( $status == 'success')
{
$filestream = $malaca_data['filestream'];
$decoded = base64_decode($filestream);
$filename=$orderid."_ReturnLabel.pdf";
$file = $root."/".$orderid."_ReturnLabel.pdf";
$baseurlval = $baseurl."/".$filename;
file_put_contents($file, $decoded);
if (file_exists($file)){
$response1 = array('status'=> 'success','msg'=>$filename,'base_url'=>$baseurlval);
$response1= json_encode($response1);
}
else{
echo "+1";
}
}
}
echo $response1;
}
}


/*  Button added in Woocommerce order table page */
function malca_add_myown_column( $columns ) {
$new_columns = array();
foreach ( $columns as $column_name => $column_info ) {
$new_columns[ $column_name ] = $column_info;
if ( 'order_total' === $column_name ) {
$new_columns['malca_order_label'] = __( 'Print Label', 'my-textdomain' );
}
}
return $new_columns;
}
add_filter( 'manage_edit-shop_order_columns', 'malca_add_myown_column');


function malca_add_myown_column_retun( $columns ) {
$new_columns = array();
foreach ( $columns as $column_name => $column_info ) {
$new_columns[ $column_name ] = $column_info;
if ( 'malca_order_label' === $column_name ) {
$new_columns['malca_order_labelretun'] = __( 'Return Label', 'my-textdomain' );
}
}
return $new_columns;
}
add_filter( 'manage_edit-shop_order_columns', 'malca_add_myown_column_retun');


function malca_customorders_list_column_print($column)
{
if ( 'malca_order_label' === $column ) {
global $post,$wpdb;
$table_name = $wpdb->prefix . "orders_info";
$row = $wpdb->get_row("SELECT * From $table_name WHERE order_id =$post->ID",ARRAY_A);
$trackingcode =$row['tracking_code'];
$nonce=wp_create_nonce('malca_file_nonce');
$nonce=esc_attr($nonce);
$url = admin_url("admin.php?page=malca-amit-shipping-service/template/print_label.php&order_id=$post->ID&_wpnonce=$nonce");
echo "
<a href='".  $url."' class='button-primary' target='blank' width: 4ch; style=' margin-left:3px; width:48%; min-width: 95px; max-width:100px; text-align:center; data-order='$post->ID'>Print label</a>
";
}
}
add_action( 'manage_shop_order_posts_custom_column' , 'malca_customorders_list_column_print');


function malca_customorders_list_column_return($column)
{
global $post,$wpdb;
$table_name = $wpdb->prefix . "orders_info";
$row = $wpdb->get_row("SELECT * From $table_name WHERE order_id =$post->ID",ARRAY_A);
$trackingcode =$row['tracking_code'];
$nonce=wp_create_nonce('malca_file_nonce');
$nonce=esc_attr($nonce);
if ( 'malca_order_labelretun' === $column ) {
$returnurl= admin_url("admin.php?page=malca-amit-shipping-service/template/return_label.php&order_id=$post->ID&trackingnumber=$trackingcode&_wpnonce=$nonce");
$cu = new WC_Countries();
$concode = $cu->get_base_country();
$order = new WC_Order($post->ID);
$country_code = $order ->get_shipping_country();
if($concode == $country_code && $trackingcode!=0)
{
echo "
<a href='".$returnurl."' class='button-primary' target='blank' style=' margin-right:0%; width:48%; min-width:95px; max-width:100px; text-align:center; data-order='$post->ID'>Return label</a>
";
}
}
}
add_action( 'manage_shop_order_posts_custom_column' , 'malca_customorders_list_column_return',10);