function malca_download_label(orderID)
{

 setTimeout(function(){  

  jQuery.ajax({

    type:'POST',
    url:my_ajax_obj.ajax_url,
     datatype : "json",
    data:{_ajax_nonce: my_ajax_obj.nonce, action:'malca_print_label',id:orderID }

  })
  .done(function(value){
   console.log(value);
   var value = value.slice(0, -1);
   var res_data =JSON.parse(value);

   var urlval = res_data['base_url'];
   if (res_data['status'] == 'success') {

    jQuery('.orderTracking-'+orderID).html(res_data['tracking_number']);
    jQuery('.Fulfilment-'+orderID).html(res_data['order_status']);
    jQuery('#order_idval-'+orderID).attr('href',urlval );
    jQuery('#order_idval-'+orderID)[0].click();
    jQuery('#myModal').modal('hide');
  }
  else{

    jQuery('.modal-body p').html('<span style="color:red; font-weight:bold;">'+res_data['msg']+'</span>    <br><br><button type="button" class="btn-danger mybtn btn" data-dismiss="modal">Close</button>');
	 
  }
	  

 });


}, 1000);


}


function malca_return_label_download(orderID,tracking_code)
{

 setTimeout(function(){     

  jQuery.ajax({
    type:'POST',

    url:my_ajax_obj.ajax_url,
    data:{_ajax_nonce: my_ajax_obj.nonce, action:'malca_return_label', id:orderID, trackingnumber:tracking_code }

  })
  .done(function(value){
   console.log(value);
    var value = value.slice(0, -1);
   var res_data = JSON.parse(value);
  
   var urlval = res_data['base_url'];

   if (res_data['status'] == 'success') {

  
   var data = jQuery('#order_idval-'+orderID).attr('href',urlval );

    jQuery('#order_idval-'+orderID)[0].click();
    jQuery('#myModal').modal('hide');
   // $('#return_btn-'+orderID).attr('onclick','malca_return_label_download(\''+orderID+'\',\''+tracking_code+'\')');

  }
  else
  {
    jQuery('.modal-body p').html('<span style="color:red; font-weight:bold;">'+res_data['msg']+'</span><br><br><button type="button" class="btn-danger btn" data-dismiss="modal">Close</button>');
  }

});


}, 1000);



}




