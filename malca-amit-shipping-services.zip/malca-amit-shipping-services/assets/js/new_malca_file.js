jQuery( document ).ready(function() {


   setTimeout(function(){ 
     jQuery('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
    localStorage.setItem('activeTab', jQuery(e.target).attr('href'));
      

  });
  var activeTab = localStorage.getItem('activeTab');
  if(activeTab){
    jQuery('#myTab a[href="' + activeTab + '"]').tab('show');

  }

   }, 500);

     
    jQuery('#myModal').modal({
        backdrop: 'static',
        keyboard: false
    });
	  jQuery('#myModal').modal('hide');
    jQuery('.logindata').click(function(){
     var username = jQuery("input[name='username']").val();
     var pass = jQuery("input[name='password']").val();
     var stationcode = jQuery("input[name='stationcode']").val();

    if( ( username.trim() != "" ) && ( pass.trim() != "" ) && ( stationcode.trim() != "" ) ) {
      jQuery('#mModal').modal('show');

    }

  });

  jQuery('.singout_val').click(function(){

    jQuery('#myModal').modal('show');

  });

  var options="";
  jQuery("#filter1").on('change',function(){
    var value=jQuery(this).val();

    jQuery("#filter2").show();
    if(value=="fulfillment_status")
    {
     options="<option>Select a value</option>"
     +"<option value='1'>Fulfilled</option>"
     +"<option value='0'>Unfulfilled</option>";
     jQuery("#filter2").html(options);
   }
   else if(value=="date")
   {
    options='<option>Select a value</option>'
    +'<option value="in_the_last_week">In The Last Week</option>'+'<option value="in_the_last_month">In The Last Month</option>'+'<option value="in_the_last_year">In The Last Year</option>';
    jQuery("#filter2").html(options);
  }
  else if(value=="status")
  {
    options='<option>Select a value</option>'
    +'<option value="completed">Completed</option>'+'<option value="cancel">Cancelled</option>'+'<option value="Any">Any</option>';
    jQuery("#filter2").html(options);
  }
  else{
    jQuery("#filter2").find('option').remove();
  }
});


  jQuery(".faq-c").click(function(){
        jQuery(this).children(".faq-a").toggle();
    });


  jQuery('.refresh_orders').click(function(){

  
      window.location = 'admin.php?page=malca-amit-shipping-service/template/order.php';

  });


 jQuery('.filterload').click(function(){

   jQuery('#myModal').modal('show');


 });
	
	

	jQuery('.modal-body p').on("click",'.mybtn',function(){
	var url= jQuery('#loader-url').val();
    jQuery('.modal-body p').html('<img src="'+url+'"/>');
		 setTimeout(function(){ 
		  jQuery('#myModal').modal('hide');
		 },1000);
	 });
	



   
});

    